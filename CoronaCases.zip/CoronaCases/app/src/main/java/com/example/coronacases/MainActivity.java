package com.example.coronacases;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    //Declaring Spinner
    Spinner sp;
    //Declare the list view object
    ListView lv;
    String [] continents ={"North America","South America","Europe","Asia"};
    //Create a list
    ArrayList<Corona> country = new ArrayList<Corona>();
    ArrayList<Corona> contCase = new ArrayList<Corona>();
    public  static String Countryname;
    public  static int CountryCases;
    public static int CurrentCases;
    public static int CurrentDeath;
    public static int CurrentRecovered;

    //method to fill the details
    public void fillData(){

        country.add(new Corona("North America","Canada",40190,2005,24230,13789));
        country.add(new Corona("North America","USA",848779,47230,717456,84723));
        country.add(new Corona("North America","Mexico",10592,970,6947,2627));
        country.add(new Corona("South America","Brazil",40190,2005,24230,13789));
        country.add(new Corona("South America","Peru",40190,2005,24230,13789));
        country.add(new Corona("Europe","UK",133456,18100,115051,22567));
        country.add(new Corona("Europe","France",159315,21340,79880,40657));
        country.add(new Corona("Europe","Germany",150234,5315,99400,45560));
        country.add(new Corona("Europe","Spain",208455,21717,107345,85912));
        country.add(new Corona("Europe","Italy",187652,25085,107668,545376));
        country.add(new Corona("Asia","China",82345,4632,959,77207));
        country.add(new Corona("Asia","Japan",11950,299,10227,1424));
        country.add(new Corona("Asia","India",21370,681,16319,4370));
        country.add(new Corona("Asia","South Korea",10702,240,2051,8233));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initialising the spinner
        sp=findViewById(R.id.spContinent);
        //initialising the list
        lv=findViewById(R.id.lvCountries);
        fillData();
        //Creating the adapter for the spinner
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,continents);
        aa.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);
        lv.setOnItemClickListener(this);
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        contCase.clear();//contCase is an Array list
        String make = continents[i];//it is an array of continents
        for (int j = 0; j < country.size(); j++)
            if (country.get(j).getContinent().equals(make))
                contCase.add(country.get(j));
        lv.setAdapter(new CoronaAdapter(this, contCase));

    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Countryname = contCase.get(i).getCountry();
        CountryCases = contCase.get(i).getAllCases();
        CurrentCases = contCase.get(i).getActiveCases();
        CurrentDeath = contCase.get(i).getDeath();
        CurrentRecovered = contCase.get(i).getRecovered();

        Intent intent = new Intent(this,CasesDetails.class);
        startActivity(intent);

    }
}
