package com.example.coronacases;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class CasesDetails extends AppCompatActivity {
    EditText AllCasesEt,ActiveCasesEt,DeathEt,RecoveredEt;
    TextView CountryNameTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cases_details);
        getIntent().getStringExtra("CountyName");

        CountryNameTv=findViewById(R.id.tvCntryName);
        CountryNameTv.setText(MainActivity.Countryname);
        AllCasesEt=findViewById(R.id.etAllCases);
        AllCasesEt.setText(String.format("%d",MainActivity.CountryCases));
        ActiveCasesEt =findViewById(R.id.etActiveCases);
        ActiveCasesEt.setText(String.format("%d",MainActivity.CurrentCases));
        DeathEt=findViewById(R.id.etDeath);
        DeathEt.setText(String.format("%d",MainActivity.CurrentDeath));
        RecoveredEt=findViewById(R.id.etRecovered);
        RecoveredEt.setText(String.format("%d",MainActivity.CurrentRecovered));

    }

}
